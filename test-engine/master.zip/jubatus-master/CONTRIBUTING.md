How to Contribute
=================

Please check our Contibution Guideline first.

* English : http://jubat.us/en/developers/howtocontribute.html
* Japanese: http://jubat.us/ja/developers/howtocontribute.html

Copyright
---------
(C) PFN & NTT
