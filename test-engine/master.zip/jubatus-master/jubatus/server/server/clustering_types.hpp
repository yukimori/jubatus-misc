// This file is auto-generated from clustering.idl(0.9.4-19-gc665909) with jenerator version 0.8.5-6-g5a2c923/feature/refactoring_clustering_api
// *** DO NOT EDIT ***

#ifndef JUBATUS_SERVER_SERVER_CLUSTERING_TYPES_HPP_
#define JUBATUS_SERVER_SERVER_CLUSTERING_TYPES_HPP_

#include <stdint.h>

#include <map>
#include <string>
#include <vector>
#include <utility>

#include "jubatus/core/fv_converter/datum.hpp"
#include <msgpack.hpp>

#include "jubatus/core/fv_converter/datum.hpp"
#include "jubatus/core/clustering/types.hpp"

namespace jubatus {

}  // namespace jubatus

#endif  // JUBATUS_SERVER_SERVER_CLUSTERING_TYPES_HPP_
